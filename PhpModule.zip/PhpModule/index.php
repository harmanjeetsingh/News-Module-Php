<?php
require_once './admin/database.php';
$db = new database();
?>
<?php
if (isset($_GET['c'])) {


    $cat = filter_input(INPUT_GET, "c");
    $catName = $db->getCatNameById($cat);
    $query = "select * from `post` where cat='$cat'";
} else {
    $query = "select * from `post`";

    $catName = 'HOME';
}
?>
<html>
    <head>
        <title><?php echo $catName; ?></title>
        <?php require_once 'statichead.php'; ?>
    </head>
    <body>
        <?php
        include_once './navigation.php';
        ?>
        <a href="admin/index.php" class="btn btn-success pull-right" style="margin-top: 30px; margin-right: 40px;">LOGIN</a>
        <div class="container">
            <div class="alert alert-info"><h1 align="center"><?php echo $catName; ?></h1></div>
                <?php
                $result = $db->query($query);
                while ($r = $db->fetchArray($result)) {
                    $id = $r['id'];
                    if (file_exists("imgs/$id.jpg")) {
                        $img = "<img src='imgs/$id.jpg' align='left'>";
                    } else {
                        $img = "";
                    }
                    echo "<h1><a href='read.php?id=$id'>" . $r['title'] . "</a></h1><p>$img" . substr($r['body'], 0, 255) . "</p><p>" . $r['keyword'] . "</p><p>" . $r['description'] . "</p><hr>";
                }
                ?>
        </div>
    </body>
</html>