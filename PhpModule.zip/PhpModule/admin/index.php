<?php
require_once './session.php';
require_once './database.php';
$db = new database();
?>
<?php
if (isset($_SESSION['user'])) {
    
}
?>
<html>
    <head>
        <title>NEW POST</title>
        <?php require_once 'staticHead.php'; ?>

        <?php require_once 'navigation.php'; ?>
    <h1 class="jumbotron active" align="center">Home</h1>
<?php require_once 'footer.php'; ?>
</body>
</html>