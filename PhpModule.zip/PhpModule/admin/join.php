<?php
require_once './database.php';
$db = new database();
if (isset($_POST['logBtn'])) {
    $username = filter_input(INPUT_POST, "username");
    $password = filter_input(INPUT_POST, "password");
    $name = filter_input(INPUT_POST, "name");
    $password = sha1($password);
    $sql = "INSERT INTO login (`username`,`password`,`name`)
 VALUES ('$username', '$password', '$name')";
    $db->query($sql);
    header("location: index.php");
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>JOIN</title>
        <?php require_once 'staticHead.php'; ?>
    </head>
    <body>


        <h1 class="jumbotron" align="center">Join Us</h1>
        <div class="container">
            <form method="post" action="">
                <div>
                    <div style="margin-left: 30px;">
                        <div class="form-group"><label><b>Name</b></label><br><input type="text" name="name" class="form-control" required="required" max="30"></div>
                        <div class="form-group"><label><b>Username</b></label><br><input type="text" name="username" class="form-control" required="required" max="30"></div>
                        <div class="form-group"><label><b>Password</b></label><br><input type="password" name="password" class="form-control" required="required" max="60"></div>
                        <input type="submit" name="logBtn" class="btn btn-primary">
                    </div>
                </div>
            </form>
        </div>
    </body>
</html>