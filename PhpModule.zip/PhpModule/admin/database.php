<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of database
 *
 * @author Harman
 */
class database {

    //put your code here
    private $link;

    public function __construct() {
        $this->link = $this->connect();
    }

    public function connect() {
        return mysqli_connect('127.0.0.1', 'root', '', 'form');
    }

    public function query($query) {
        return mysqli_query($this->link, $query);
    }

    public function fetchArray($result) {
        return mysqli_fetch_array($result);
    }

    public function numRow($result) {
        return mysqli_num_rows($result);
    }
    public function getCatNameById($id) {
        $q="select * from category where id=$id";
        $result=$this->query($q);
        $r=$this->fetchArray($result);
        return $r['name'];
    }

}
