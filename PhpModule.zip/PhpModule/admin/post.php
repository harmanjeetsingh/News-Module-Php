<?php
require_once './session.php';
?>
<?php
require_once './database.php';
$db = new database();
if (isset($_POST['submit'])) {

    $title = addslashes(filter_input(INPUT_POST, "title"));
    $body = addslashes(filter_input(INPUT_POST, "body"));
    $keyword = addslashes(filter_input(INPUT_POST, "keyword"));
    $description = addslashes(filter_input(INPUT_POST, "description"));
    $cat = filter_input(INPUT_POST, "cat");
    $username = $_SESSION['username'];
    $query = "INSERT INTO post(`title`,`body`,`user`,`keyword`,`description`,`cat`)
              VALUES('$title','$body','$username','$keyword','$description','$cat')";
    $db->query($query);
    header("location: mypost.php");
}
?>
<html>
    <head>
        <title>NEW POST</title>
        <?php require_once 'staticHead.php'; ?>
    </head>
    <body>
        <?php require_once 'navigation.php'; ?>

        <div class="container">
            <form method="post" action="">
                <div class="form-group"><label>Title</label><input name="title" class="form-control" type="text"></div>
                <div class="form-group"><label>Body</label><textarea name="body" class="form-control"></textarea></div>
                <div class="form-group"><label>Keyword</label><input name="keyword" class="form-control" type="text"></div>
                <div class="form-group"><label>Description</label><textarea name="description" class="form-control"></textarea></div>
                <div class="form-group">
                    <label>Category</label>
                    <select name="cat" class="form-control">
                        <?php
                        $q = "SELECT * FROM category ORDER BY name";
                        $result = $db->query($q);
                        while ($r = $db->fetchArray($result)) {
                            echo '<option value="' . $r['id'] . '">' . $r['name'] . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <input type="submit" name="submit" class="btn btn-success">
            </form>
        </div>

        <?php require_once 'footer.php'; ?>
    </body>
</html>