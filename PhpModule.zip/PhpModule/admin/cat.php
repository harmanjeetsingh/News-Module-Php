<?php
require_once './session.php';
?>
<?php
require_once './database.php';
$db = new database();
if (isset($_POST['submit'])) {

    $name = ucwords(strtolower(trim(filter_input(INPUT_POST, "name"))));
    $query = "INSERT INTO category(`name`)
              VALUES('$name')";
    $db->query($query);
    header("location: cat.php");
}
?>
<html>
    <head>
        <title> Category</title>
        <?php require_once 'staticHead.php'; ?>
    </head>
    <body>
        <?php require_once 'navigation.php'; ?>

        <div class="container">

            <div class="col-sm-4">
                <ul class="list-group">

                    <?php
                    $q = "SELECT * FROM category ORDER BY name";
                    $result = $db->query($q);
                    while ($r = $db->fetchArray($result)) {
                        echo '<li class="list-group-item">' . $r['name'] . '</li>';
                    }
                    ?>
                </ul>
            </div>
            <div class="col-sm-4">
                <form method="post" action="">
                    <div class="form-group"><label>Name</label><input name="name" class="form-control" type="text"></div>

                    <input type="submit" name="submit" class="btn btn-success">
                </form>
            </div>
        </div>
        <?php require_once 'footer.php'; ?>
    </body>
</html>