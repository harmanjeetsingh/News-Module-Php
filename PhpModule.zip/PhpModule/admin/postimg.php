<?php
require_once './session.php';
?>
<?php
require_once './database.php';
require_once './image_rezise.php';
$db = new database();
if (isset($_POST['submit'])) {
    $id = addslashes(filter_input(INPUT_POST, "id"));
    $imgFile = $_FILES['postimg'];
    $imgName = $id . '.jpg';
    move_uploaded_file($_FILES['postimg']["tmp_name"], "../imgs/$imgName");
    $imagepath = $imgName;
    $save = "../imgs/" . $imagepath;
    $saveBig = "../imgs/big/" . $imagepath;
    resize_image($save, $saveBig, 512, 512);
    resize_image($save, $save, 150, 150);
    header("location: mypost.php");
}
$id = filter_input(INPUT_GET, "id");
?>
<html>
    <head>
        <title>NEW POST</title>
        <?php require_once 'staticHead.php'; ?>
    </head>
    <body>
        <?php require_once 'navigation.php'; ?>

        <div class="container">
            <form method="post" action="" enctype="multipart/form-data">
                <div class="form-group">
                    <input type="file" name="postimg" class="form-control">
                    <input type="hidden" name="id"  value="<?= $id ?>">
                </div>
                <input type="submit" name="submit" class="btn btn-success">
            </form>
        </div>

        <?php require_once 'footer.php'; ?>
    </body>
</html>