
<?php

include 'staticHead.php';
include'session.php';
include_once 'database.php';
$id=$_GET['id'];
$db = new database();
$user = $_SESSION['username'];
$query = "DELETE FROM `post` WHERE id=$id AND user='$user'";
$db->query($query);
@unlink("../imgs/$id.jpg");
@unlink("../imgs/big/$id.jpg");
header("location: mypost.php");

