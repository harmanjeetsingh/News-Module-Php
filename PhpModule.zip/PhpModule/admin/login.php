<?php
session_start();
require_once './database.php';
$db = new database();
if (isset($_POST['logBtn'])) {



    $password = sha1(filter_input(INPUT_POST, 'password'));
    $username = filter_input(INPUT_POST, 'username');

    $query = "select * from `login` where `username`='$username' AND `password`='$password'";
    $result = $db->query($query);
    $num = $db->numRow($result);


    if ($num == 1) {
        $r = $db->fetchArray($result);
        $_SESSION['login'] = true;
        $_SESSION['id'] = $r['id'];
        $_SESSION['username'] = $username;
        $_SESSION['name'] = $r['name'];
        $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
        $_SESSION['time'] = date(time());
        header('location: index.php');
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>LOGIN</title>
        <?php require_once 'staticHead.php'; ?>
    </head>
    <body>


        <h1 class="jumbotron" align="center">Login</h1>
        <div class="container">
            <form method="post" action="">
                <div>
                    <div style="margin-left: 30px;">
                        <div class="form-group"><label><b>Username</b></label><br><input type="text" name="username" class="form-control"></div>
                        <div class="form-group"> <label><b>Password</b></label><br><input class="form-control" type="password" name="password"></div>
                        <div class="form-group" style="width: 80px;"><a href="join.php" class="form-control" align="center">Join Us</a></div>
                        <input type="submit" name="logBtn" class="btn btn-primary">
                    </div>
                </div>
            </form>
        </div>
    </body>
</html>