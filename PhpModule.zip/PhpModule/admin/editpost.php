<?php
require_once './session.php';
?>
<?php
require_once './database.php';
$db = new database();
if (isset($_POST['submit'])) {
    $id = filter_input(INPUT_POST, 'id');
    $title = addslashes(filter_input(INPUT_POST, "title"));
    $body = addslashes(filter_input(INPUT_POST, "body"));
    $keyword = addslashes(filter_input(INPUT_POST, "keyword"));
    $description = addslashes(filter_input(INPUT_POST, "description"));
    $cat = filter_input(INPUT_POST, "cat");
    $catName = $db->getCatNameById($cat);
    $username = $_SESSION['username'];
    $query = "UPDATE `post` SET `title`='$title',`body`='$body',`user`='$username',`keyword`='$keyword',`description`='$description',`cat`='$cat' WHERE id='$id'";
    $db->query($query);
    header("location: mypost.php");
    if (!$username) {
        header("location: mypost.php");
    }
}
$id = filter_input(INPUT_GET, 'id');
$q = "select * from `post` where `id`=$id";
$result = $db->query($q);
$r = $db->fetchArray($result);
?>
<html>
    <head>
        <title>NEW POST</title>
        <?php require_once 'staticHead.php'; ?>
        <script src="//cdn.ckeditor.com/4.7.2/full/ckeditor.js"></script>

    </head>
    <body>
        <?php require_once 'navigation.php'; ?>

        <div class="container">
            <form method="post" action="">
                <input type="hidden" name="id" value="<?= $r['id'] ?>">
                <div class="form-group"><label>Title</label><input name="title" class="form-control" type="text" value="<?= $r['title'] ?>"></div>
                <div class="form-group"><label>Body</label><textarea name="body" class="form-control"><?= $r['body'] ?></textarea></div>
                <div class="form-group"><label>Keyword</label><input name="keyword" class="form-control" type="text" value="<?= $r['keyword'] ?>"></div>
                <div class="form-group"><label>Description</label><textarea name="description" class="form-control"><?= $r['description'] ?></textarea></div>
                <div class="form-group">
                    <label>Category</label><select name="cat" class="form-control" value="<?= $r['cat'] ?>">
                        <?php
                        $q = "SELECT * FROM category ORDER BY name";
                        $result = $db->query($q);
                        while ($r = $db->fetchArray($result)) {
                            echo '<option value="' . $r['cat'] . '">' . $r['name'] . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <input type="submit" name="submit" class="btn btn-success">
            </form>
        </div>
        <script src="tinymce/js/tinymce/jquery.tinymce.min.js"></script>
        <script src="tinymce/js/tinymce/tinymce.min.js"></script>
        <script>
            tinymce.init({
                selector: 'textarea',
                height: 500,
                menubar: false,
                plugins: [
                    'advlist autolink lists link image charmap print preview anchor textcolor',
                    'searchreplace visualblocks code fullscreen',
                    'insertdatetime media table contextmenu paste code help'
                ],
                toolbar: 'insert | undo redo |  styleselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
                content_css: [
                    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
                    '//www.tinymce.com/css/codepen.min.css']
            });
        </script>
        <?php require_once 'footer.php'; ?>
    </body>
</html>