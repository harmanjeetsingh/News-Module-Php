<?php
include './statichead.php';
?>
<style type="text/css">
</style>
<div class="container">
    <div class="col-sm-4 img-responsive"><img src="news.jpg" style="width: 100%"></div>
    <div class="col-sm-8">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <!-- Brand and toggle get grouped for better mobile display -->
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <a class="navbar-brand" href="#">Category</a>
                        <li><a href="index.php">Home</a></li>
                        <?php
                        $q = "SELECT * FROM category ORDER BY name";
                        $result = $db->query($q);
                        while ($r = $db->fetchArray($result)) {
                            echo '<li><a  href="?c=' . $r['id'] . '">' . $r['name'] . '</a></li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav> 

    </div>

</div>