<?php
require_once './admin/database.php';
$db = new database();
        $id = $_GET['id'];
?>
<html>
    <head>
        <?php require_once './statichead.php'; ?>
    </head>
    <body>
        <div class="container">
        <?php
        
        $query = "SELECT * FROM `post` WHERE id='$id'";
        $result = $db->query($query);
        while ($r = $db->fetchArray($result)) {
            if (file_exists("imgs/big/$id.jpg")) {
                $img = "<img src='imgs/big/$id.jpg' width='100%'>";
            } else {
                $img = "";
            }
            echo "<h1 class='alert alert-info' align='center'>" . $r['title'] . "</h1><div class='alert alert-info'><p><div class='col-sm-4 pull-right'>$img</div>" . $r['body'] . "</p><h6>" . $r['keyword'] . "</h6><p>" . $r['description'] . "</p><div>";
        }
        ?>
            <div class="addthis_inline_share_toolbox"></div>
        </div>
        <!-- Go to www.addthis.com/dashboard to customize your tools -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-59cbb7cacb156b85"></script>

    </body>
</html>